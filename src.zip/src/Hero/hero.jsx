import React from 'react';
import { useRef } from 'react';
import style from './hero.css';
import curve from './assets/curve.svg';
import cert from './assets/certificate.png';
import scholarship from './assets/scholarship.png';
import cart from './assets/cart.png';

function Hero () {
    
    const roller = useRef();

    const rollFunction = () => {
        roller.current.scrollBy(100,0);
    };

        return (
            <div className='Hero'>
                <div className='banner'>
                    <div className='rolls' ref={roller}>
                        <div className='roll-1'>
                            <div className='intro'>
                                <h1>Become <span className='tech'>Tech</span> Savy By Learning With Us</h1>
                                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate voluptatibus autem numquam delectus?</p>
                                <button className='sign'>Learn more</button>
                                <img className='curve' src={curve} alt="" />
                            </div>
                        </div>
                        <div className='roll-2'>
                            <div className='intro'>
                                <h1>Get <span className='tech'>Tech</span> Savy By Learning With Us</h1>
                                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate voluptatibus autem numquam delectus?</p>
                                <button className='sign'>Learn more</button>
                                <img className='curve' src={curve} alt="" />
                            </div>
                        </div>
                        <div className='roll-2'>
                            <div className='intro'>
                                <h1>bring <span className='tech'>Tech</span> Savy By Learning With Us</h1>
                                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Voluptate voluptatibus autem numquam delectus?</p>
                                <button className='sign'>Learn more</button>
                                <img className='curve' src={curve} alt="" />
                            </div>
                        </div>
                    </div>

                    <div>
                        {/* <button onClick={rollFunction}>nrxt</button> */}
                    </div>

                    <div className='options'>
                        <div className='inner'>
                            <b><img className='opt-icons' src={scholarship}></img>Scholarships</b>
                            <b><img className='opt-icons' src={cert}></img>Certificates</b>
                            <b><img className='opt-icons' src={cart}></img>Our Store</b>
                        </div>
                    </div>
                </div>
            </div>
        );
    
}

export default Hero;
