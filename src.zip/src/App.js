import logo from './logo.svg';
import './App.css';
import Navbar from './Navigation/navbar';
import Hero from './Hero/hero';
import Services from './Services/services';


function App() {
  return (
    <div className="App">
      
      
      <Navbar/>
      <Hero/>
      <Services/>
    </div>
  );
}

export default App;
