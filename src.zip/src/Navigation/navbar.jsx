import React from 'react';
import style from './navbar.css';
import logo from './LogoMaker.png';
import vector from './vector.png';
import search from './search.png';

class Navbar extends React.Component {
    constructor() {
      super();
  
    }
  
    render() {
      return (
        <div className='Navbar'>
              <nav>
                <img className='logo' src={logo}/>
                <div className='items'>
                    <ul>
                        <li>Courses <img src={vector}></img></li>
                        <li>Our Services <img src={vector}></img></li>
                        <li>About Us</li>
                        <li>Contact</li>
                    </ul>
                </div>
                <div className='search'>
                    <input type='text' placeholder='Search courses'></input>
                    <img className='search-icon' src={search}></img>
                </div>
                <div className='nav-btn'>
                    <button className='sign'>Sign In</button>
                    <button>Register</button>
                </div>
              </nav>
        </div>
      );
    }
  }
  
  export default Navbar;
  